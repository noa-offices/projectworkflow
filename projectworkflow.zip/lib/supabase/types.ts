export type AppRole =
  | "system_owner"
  | "admin_manager"
  | "sales_designer"
  | "viewer";

export type AccountStatus = "pending" | "active" | "disabled";
